package com.example.tdsmedroudn2;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView txtview;
    Button addbtn;
    EditText inp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtview = findViewById(R.id.hw);
        addbtn = findViewById(R.id.addbtn);
        inp = findViewById(R.id.editTT);

        addbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String topr = inp.getText()+"";
                topr = topr.substring(0, 3) + "inha";
                txtview.setText(topr);
            }
        });

    }
}